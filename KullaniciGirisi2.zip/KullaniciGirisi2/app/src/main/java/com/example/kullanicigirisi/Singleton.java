package com.example.kullanicigirisi;

public class Singleton {
    private String adiSoyadi;
    private String email;
    private String telefon;
    private static Singleton singleton;

    private Singleton() {
    }

    //Kullanıcı Adı için getter ve setter
    public String getAdiSoyadi() {
        return adiSoyadi;
    }

    public void setAdiSoyadi(String adiSoyadi) {
        this.adiSoyadi = adiSoyadi;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefon() {
        return telefon;
    }

    public void setTelefon(String telefon) {
        this.telefon = telefon;
    }


    //Singleton sınıfının nesne oluşturması
    public static Singleton getInstance() {
        if (singleton == null) {
            singleton = new Singleton();
        }
            return singleton;
        }

}
