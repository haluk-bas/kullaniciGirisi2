package com.example.kullanicigirisi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;

import com.example.kullanicigirisi.databinding.ActivityAnaSayfaBinding;

public class AnaSayfa extends AppCompatActivity {

    private ActivityAnaSayfaBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityAnaSayfaBinding.inflate(getLayoutInflater());
        View view = binding.getRoot();
        setContentView(view);
        String adiSoyadi = Singleton.getInstance().getAdiSoyadi();
        String email = Singleton.getInstance().getEmail();
        String telefon = Singleton.getInstance().getTelefon();
        binding.textViewAdiSoyadi.setText(adiSoyadi);
        binding.textViewEmail.setText(email);
        binding.textViewTelefonNo.setText(telefon);
    }
}