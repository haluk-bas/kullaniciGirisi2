package com.example.kullanicigirisi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.kullanicigirisi.databinding.ActivityMainBinding;

import java.util.concurrent.CountedCompleter;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding bingding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        bingding = ActivityMainBinding.inflate(getLayoutInflater());
        View view = bingding.getRoot();
        setContentView(view);

    }
    public void kullaniciGirisi(View view){
        String adiSoyadi = bingding.editTextAdiSoyadi.getText().toString();
        String email = bingding.editTextTextMail.getText().toString();
        String telefon = bingding.editTextTextTelefon.getText().toString();

        Singleton singleton = Singleton.getInstance();
        singleton.setAdiSoyadi(adiSoyadi);
        singleton.setEmail(email);
        singleton.setTelefon(telefon);

        Intent intent = new Intent(this,AnaSayfa.class);
        startActivity(intent);
    }

}